function nagyitKep(melyikKep) {
    document.getElementById('nagykep').src = melyikKep;
}

function visszaKep() {
    document.getElementById('nagykep').src = "ures.jpg";
}

function kivalaszt(melyikTermek) {
    let darab = prompt("Hány darabot szeretne?");
    if (darab != null && darab != "") {
        let kosarDiv = document.getElementById('kosar')
        let ujSor = document.createElement('p');
        ujSor.innerHTML = darab + " db " +melyikTermek ;
        kosarDiv.appendChild(ujSor);
    }
}